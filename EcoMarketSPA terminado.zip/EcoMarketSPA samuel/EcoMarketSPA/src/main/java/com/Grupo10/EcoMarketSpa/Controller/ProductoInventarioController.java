package com.Grupo10.EcoMarketSpa.Controller;

import com.Grupo10.EcoMarketSpa.Model.ProductoInventario;
import com.Grupo10.EcoMarketSpa.Repository.ProductInventoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/producto-inventario")
public class ProductoInventarioController {

    @Autowired
    private ProductInventoryRepository productInventoryRepository;

    @GetMapping
    public List<ProductoInventario> getAllProductoInventario() {
        return productInventoryRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductoInventario> getProductoInventarioById(@PathVariable int id) {
        Optional<ProductoInventario> productoInventario = productInventoryRepository.findById(id);
        return productoInventario.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ProductoInventario createProductoInventario(@RequestBody ProductoInventario productoInventario) {
        return productInventoryRepository.save(productoInventario);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProductoInventario> updateProductoInventario(@PathVariable int id, @RequestBody ProductoInventario details) {
        Optional<ProductoInventario> optional = productInventoryRepository.findById(id);
        if (optional.isPresent()) {
            ProductoInventario entity = optional.get();
            // Actualiza los campos que correspondan, por ejemplo:
            // entity.setCantidad(details.getCantidad());
            return ResponseEntity.ok(productInventoryRepository.save(entity));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProductoInventario(@PathVariable int id) {
        if (productInventoryRepository.existsById(id)) {
            productInventoryRepository.deleteById(id);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
