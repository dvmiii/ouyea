package com.Grupo10.EcoMarketSpa.Service;

import com.Grupo10.EcoMarketSpa.Model.ItemOrder;
import com.Grupo10.EcoMarketSpa.Repository.ItemOrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ItemOrderService {

    @Autowired
    private ItemOrderRepository itemOrderRepository;

    // Crear o actualizar un ItemOrder
    public ItemOrder saveItemOrder(ItemOrder itemOrder) {
        return itemOrderRepository.save(itemOrder);
    }

    // Obtener todos los ItemOrder
    public List<ItemOrder> getAllItemOrders() {
        return itemOrderRepository.findAll();
    }

    // Obtener un ItemOrder por ID
    public Optional<ItemOrder> getItemOrderById(int id) {
        return itemOrderRepository.findById(id);
    }

    // Eliminar un ItemOrder por ID
    public void deleteItemOrder(int id) {
        itemOrderRepository.deleteById(id);
    }

    // Actualizar un ItemOrder
    public ItemOrder updateItemOrder(int id, ItemOrder itemOrderDetails) {
        Optional<ItemOrder> optionalItemOrder = itemOrderRepository.findById(id);

        if (optionalItemOrder.isPresent()) {
            ItemOrder existingItemOrder = optionalItemOrder.get();
            existingItemOrder.setProductos(itemOrderDetails.getProductos());
            existingItemOrder.setCantidad(itemOrderDetails.getCantidad());
            existingItemOrder.setPrecioUnitario(itemOrderDetails.getPrecioUnitario());
            return itemOrderRepository.save(existingItemOrder);
        } else {
            return null; // o lanza una excepción personalizada si prefieres
        }
    }
}
