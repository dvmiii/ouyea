package com.Grupo10.EcoMarketSpa.Service;

import com.Grupo10.EcoMarketSpa.Model.Factura;
import com.Grupo10.EcoMarketSpa.Repository.FacturaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FacturaService {

    @Autowired
    private FacturaRepository facturaRepository;

    public Factura saveFactura(Factura factura) {
        return facturaRepository.save(factura);
    }

    public List<Factura> getAllFacturas() {
        return facturaRepository.findAll();
    }

    public Optional<Factura> getFacturaById(int id) {
        return facturaRepository.findById(id);
    }

    public void deleteFactura(int id) {
        facturaRepository.deleteById(id);
    }

    public Factura updateFactura(int id, Factura facturaDetails) {
        Optional<Factura> optionalFactura = facturaRepository.findById(id);

        if (optionalFactura.isPresent()) {
            Factura existingFactura = optionalFactura.get();
            existingFactura.setPedido(facturaDetails.getPedido());
            existingFactura.setFechaEmision(facturaDetails.getFechaEmision());
            existingFactura.setMontoTotal(facturaDetails.getMontoTotal());
            // método de pago no se guarda porque es @Transient
            return facturaRepository.save(existingFactura);
        } else {
            return null;
        }
    }
}
