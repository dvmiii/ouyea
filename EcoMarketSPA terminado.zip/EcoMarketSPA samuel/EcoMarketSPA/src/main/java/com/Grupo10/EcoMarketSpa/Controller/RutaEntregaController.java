package com.Grupo10.EcoMarketSpa.Controller;

import com.Grupo10.EcoMarketSpa.Model.RutaEntrega;
import com.Grupo10.EcoMarketSpa.Service.RutaEntregaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/rutas-entrega")
public class RutaEntregaController {

    @Autowired
    private RutaEntregaService rutaEntregaService;

    @GetMapping
    public List<RutaEntrega> getAllRutasEntrega() {
        return rutaEntregaService.getAllRutasEntrega();
    }

    @GetMapping("/{id}")
    public ResponseEntity<RutaEntrega> getRutaEntregaById(@PathVariable int id) {
        Optional<RutaEntrega> rutaEntrega = rutaEntregaService.getRutaEntregaById(id);
        return rutaEntrega.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public RutaEntrega createRutaEntrega(@RequestBody RutaEntrega rutaEntrega) {
        return rutaEntregaService.createRutaEntrega(rutaEntrega);
    }

    @PutMapping("/{id}")
    public ResponseEntity<RutaEntrega> updateRutaEntrega(@PathVariable int id, @RequestBody RutaEntrega details) {
        Optional<RutaEntrega> updatedRuta = rutaEntregaService.updateRutaEntrega(id, details);
        return updatedRuta.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRutaEntrega(@PathVariable int id) {
        if (rutaEntregaService.deleteRutaEntrega(id)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}

