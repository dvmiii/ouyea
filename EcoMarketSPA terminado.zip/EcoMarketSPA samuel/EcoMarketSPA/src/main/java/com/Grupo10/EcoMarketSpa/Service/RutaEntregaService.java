package com.Grupo10.EcoMarketSpa.Service;

import com.Grupo10.EcoMarketSpa.Model.RutaEntrega;
import com.Grupo10.EcoMarketSpa.Repository.RutaEntregaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RutaEntregaService {

    @Autowired
    private RutaEntregaRepository rutaEntregaRepository;

    public List<RutaEntrega> getAllRutasEntrega() {
        return rutaEntregaRepository.findAll();
    }

    public Optional<RutaEntrega> getRutaEntregaById(int id) {
        return rutaEntregaRepository.findById(id);
    }

    public RutaEntrega createRutaEntrega(RutaEntrega rutaEntrega) {
        return rutaEntregaRepository.save(rutaEntrega);
    }

    public Optional<RutaEntrega> updateRutaEntrega(int id, RutaEntrega detalles) {
        Optional<RutaEntrega> optional = rutaEntregaRepository.findById(id);
        if (optional.isPresent()) {
            RutaEntrega ruta = optional.get();
            ruta.setOrigen(detalles.getOrigen());
            ruta.setDestino(detalles.getDestino());
            ruta.setDuracionEstimada(detalles.getDuracionEstimada());
            return Optional.of(rutaEntregaRepository.save(ruta));
        } else {
            return Optional.empty();
        }
    }

    public boolean deleteRutaEntrega(int id) {
        if (rutaEntregaRepository.existsById(id)) {
            rutaEntregaRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }
}



