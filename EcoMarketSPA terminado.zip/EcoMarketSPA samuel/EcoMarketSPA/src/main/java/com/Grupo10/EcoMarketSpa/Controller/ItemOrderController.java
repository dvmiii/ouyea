package com.Grupo10.EcoMarketSpa.Controller;

import com.Grupo10.EcoMarketSpa.Model.ItemOrder;
import com.Grupo10.EcoMarketSpa.Service.ItemOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/item-orders")
@CrossOrigin(origins = "*") // Puedes ajustar esto según tu frontend
public class ItemOrderController {

    @Autowired
    private ItemOrderService itemOrderService;

    // Crear un nuevo ItemOrder
    @PostMapping
    public ResponseEntity<ItemOrder> createItemOrder(@RequestBody ItemOrder itemOrder) {
        return ResponseEntity.ok(itemOrderService.saveItemOrder(itemOrder));
    }

    // Obtener todos los ItemOrders
    @GetMapping
    public ResponseEntity<List<ItemOrder>> getAllItemOrders() {
        return ResponseEntity.ok(itemOrderService.getAllItemOrders());
    }

    // Obtener un ItemOrder por ID
    @GetMapping("/{id}")
    public ResponseEntity<ItemOrder> getItemOrderById(@PathVariable int id) {
        Optional<ItemOrder> itemOrder = itemOrderService.getItemOrderById(id);
        return itemOrder.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Actualizar un ItemOrder
    @PutMapping("/{id}")
    public ResponseEntity<ItemOrder> updateItemOrder(@PathVariable int id, @RequestBody ItemOrder itemOrderDetails) {
        ItemOrder updated = itemOrderService.updateItemOrder(id, itemOrderDetails);
        if (updated != null) {
            return ResponseEntity.ok(updated);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Eliminar un ItemOrder
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteItemOrder(@PathVariable int id) {
        itemOrderService.deleteItemOrder(id);
        return ResponseEntity.noContent().build();
    }
}
