package com.Grupo10.EcoMarketSpa.Controller;

import com.Grupo10.EcoMarketSpa.Model.ItemCart;
import com.Grupo10.EcoMarketSpa.Service.ItemCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/item-carts")
@CrossOrigin(origins = "*")
public class ItemCartContrller {

    @Autowired
    private ItemCartService itemCartService;

    @PostMapping
    public ResponseEntity<ItemCart> createItemCart(@RequestBody ItemCart itemCart) {
        return ResponseEntity.ok(itemCartService.saveItemCart(itemCart));
    }

    @GetMapping
    public ResponseEntity<List<ItemCart>> getAllItemCarts() {
        return ResponseEntity.ok(itemCartService.getAllItemCarts());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ItemCart> getItemCartById(@PathVariable int id) {
        Optional<ItemCart> itemCart = itemCartService.getItemCartById(id);
        return itemCart.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<ItemCart> updateItemCart(@PathVariable int id, @RequestBody ItemCart itemCartDetails) {
        ItemCart updated = itemCartService.updateItemCart(id, itemCartDetails);
        if (updated != null) {
            return ResponseEntity.ok(updated);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteItemCart(@PathVariable int id) {
        itemCartService.deleteItemCart(id);
        return ResponseEntity.noContent().build();
    }
}
