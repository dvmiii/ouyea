package com.Grupo10.EcoMarketSpa.Service;

import com.Grupo10.EcoMarketSpa.Model.Rol;
import com.Grupo10.EcoMarketSpa.Repository.RolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RolService {

    @Autowired
    private RolRepository rolRepository;

    public Rol saveRol(Rol rol) {
        return rolRepository.save(rol);
    }

    public List<Rol> getAllRoles() {
        return rolRepository.findAll();
    }

    public Optional<Rol> getRolById(int id) {
        return rolRepository.findById(id);
    }

    public void deleteRol(int id) {
        rolRepository.deleteById(id);
    }

    public Rol updateRol(int id, Rol rolDetails) {
        Optional<Rol> optionalRol = rolRepository.findById(id);

        if (optionalRol.isPresent()) {
            Rol existingRol = optionalRol.get();
            existingRol.setPermisoList(rolDetails.getPermisoList());
            return rolRepository.save(existingRol);
        } else {
            return null;
        }
    }
}
