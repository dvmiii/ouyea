package com.Grupo10.EcoMarketSpa.Service;

import com.Grupo10.EcoMarketSpa.Model.ItemCarrito;
import com.Grupo10.EcoMarketSpa.Repository.ItemCarritoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ItemCarritoService {

    @Autowired
    private ItemCarritoRepository itemCarritoRepository;

    public String getAllItemCarrito() {
        return itemCarritoRepository.findAll().toString();
    }
    public String addItemCarrito(ItemCarrito itemCarrito) {
        itemCarritoRepository.save(itemCarrito);
        return "ItemCarrito agregado con éxito";
    }


    public String getItemCarritoById(int id) {
        Optional<ItemCarrito> itemCarritoOpt = itemCarritoRepository.findById(id);
        if (itemCarritoOpt.isPresent()) {
            return itemCarritoOpt.get().toString();
        }
        return "ItemCarrito no encontrado";
    }


    public String deleteItemCarrito(int id) {
        Optional<ItemCarrito> itemCarritoOpt = itemCarritoRepository.findById(id);
        if (itemCarritoOpt.isPresent()) {
            itemCarritoRepository.deleteById(id);
            return "ItemCarrito eliminado con éxito";
        }
        return "ItemCarrito no encontrado";
    }

    public String updateItemCarrito(int id, ItemCarrito itemCarrito) {
        Optional<ItemCarrito> itemCarritoOpt = itemCarritoRepository.findById(id);
        if (itemCarritoOpt.isPresent()) {
            ItemCarrito existingItemCarrito = itemCarritoOpt.get();
            existingItemCarrito.setCantidad(itemCarrito.getCantidad());
            itemCarritoRepository.save(existingItemCarrito);
            return "ItemCarrito actualizado con éxito";
        }
        return "ItemCarrito no encontrado";
    }
}
