package com.Grupo10.EcoMarketSpa.Controller;

import com.Grupo10.EcoMarketSpa.Model.ItemCarrito;
import com.Grupo10.EcoMarketSpa.Service.ItemCarritoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/ItemCarrito")
public class ItemCarritoController {

    @Autowired
    private ItemCarritoService itemCarritoService;

    @GetMapping
    public String getAllItemCarrito() {
        return itemCarritoService.getAllItemCarrito();
    }

    @PostMapping
    public String addItemCarrito(@RequestBody ItemCarrito itemCarrito) {
        return itemCarritoService.addItemCarrito(itemCarrito);
    }

    @GetMapping("/{id}")
    public String getItemCarritoById(@PathVariable int id) {
        return itemCarritoService.getItemCarritoById(id);
    }

    @DeleteMapping("/{id}")
    public String deleteItemCarrito(@PathVariable int id) {
        return itemCarritoService.deleteItemCarrito(id);
    }

    @PutMapping("/{id}")
    public String updateItemCarrito(@PathVariable int id, @RequestBody ItemCarrito itemCarrito) {
        return itemCarritoService.updateItemCarrito(id, itemCarrito);
    }
}

