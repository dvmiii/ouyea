package com.Grupo10.EcoMarketSpa.Service;

import com.Grupo10.EcoMarketSpa.Model.ItemCart;
import com.Grupo10.EcoMarketSpa.Repository.ItemCartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ItemCartService {

    @Autowired
    private ItemCartRepository itemCartRepository;

    public ItemCart saveItemCart(ItemCart itemCart) {
        return itemCartRepository.save(itemCart);
    }

    public List<ItemCart> getAllItemCarts() {
        return itemCartRepository.findAll();
    }

    public Optional<ItemCart> getItemCartById(int id) {
        return itemCartRepository.findById(id);
    }

    public void deleteItemCart(int id) {
        itemCartRepository.deleteById(id);
    }

    public ItemCart updateItemCart(int id, ItemCart itemCartDetails) {
        Optional<ItemCart> optionalItemCart = itemCartRepository.findById(id);

        if (optionalItemCart.isPresent()) {
            ItemCart existingItemCart = optionalItemCart.get();
            existingItemCart.setCantidad(itemCartDetails.getCantidad());
            return itemCartRepository.save(existingItemCart);
        } else {
            return null;
        }
    }
}
